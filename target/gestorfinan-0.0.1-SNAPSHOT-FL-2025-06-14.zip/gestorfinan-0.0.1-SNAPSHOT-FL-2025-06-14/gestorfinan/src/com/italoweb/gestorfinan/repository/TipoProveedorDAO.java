package com.italoweb.gestorfinan.repository;

import com.italoweb.gestorfinan.model.TipoProveedor;

public class TipoProveedorDAO extends GenericDAOImpl<TipoProveedor, Long>{

	public TipoProveedorDAO() {
		super(TipoProveedor.class);
	}

}
