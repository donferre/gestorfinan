package com.italoweb.gestorfinan.util;

public class AppConstants {
	public static final String DIR_CONFIG = AppProperties.get("app.src").concat("/config");
    public static final String DIR_CONFIG_IMAGES = AppProperties.get("app.src").concat("/config/images");
}
