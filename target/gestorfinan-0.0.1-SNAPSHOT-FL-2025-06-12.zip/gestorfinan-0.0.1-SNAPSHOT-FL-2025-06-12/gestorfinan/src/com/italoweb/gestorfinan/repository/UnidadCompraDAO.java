package com.italoweb.gestorfinan.repository;

import com.italoweb.gestorfinan.model.UnidadCompra;

public class UnidadCompraDAO extends GenericDAOImpl<UnidadCompra, Long> {
	public UnidadCompraDAO() {
		super(UnidadCompra.class);
	}
}