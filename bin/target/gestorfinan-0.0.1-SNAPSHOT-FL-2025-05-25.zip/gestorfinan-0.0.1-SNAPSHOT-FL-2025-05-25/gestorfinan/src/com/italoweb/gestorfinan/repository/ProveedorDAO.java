package com.italoweb.gestorfinan.repository;

import com.italoweb.gestorfinan.model.Proveedor;

public class ProveedorDAO extends GenericDAOImpl<Proveedor, Long> {
	public ProveedorDAO() {
		super(Proveedor.class);
	}

}
